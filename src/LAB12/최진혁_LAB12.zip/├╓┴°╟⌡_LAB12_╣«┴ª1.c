#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(){
    char *name = "홍길동";
    char *team = "컴퓨터 공학부";

    printf("이름 : %s\n", name);
    printf("학과 : %s\n", team);
}