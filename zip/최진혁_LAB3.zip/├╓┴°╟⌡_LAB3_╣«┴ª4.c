#include <stdio.h>

int main(){
    double n;
    printf("실수를 입력하세요 : ");
    scanf("%lf", &n);

    printf("정수 부분은 %d입니다.\n", (int)n);
    
    
}