#include <stdio.h>

int main(){
    char a=65;
    printf("아스키 코드 65의 문자 : %c\n", a);
    printf("ch + 2를 문자로 변환하면 : %c\n", a+2);
}