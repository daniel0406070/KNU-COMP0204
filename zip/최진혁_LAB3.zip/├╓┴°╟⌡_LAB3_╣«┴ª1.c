#include <stdio.h>

int main(){
    char a='a';
    printf("%c\n", a+5);
    printf("%c\n", a+5);
}