int global=100;

int getglobal()
{
    return global;
}