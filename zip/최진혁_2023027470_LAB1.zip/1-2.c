#include <stdio.h>

int main(){
	int x=3;
	printf("%d의  제곱: %d\n",x,x*x);
	printf("%d의 세제곱: %d\n",x,x*x*x);
	printf("%d의 네제곱: %d\n",x,x*x*x*x);
}