#include <stdio.h>

int main(){
	int h=5,m=15;
    printf("%d시간 %d분은 %d초입니다.\n",h,m,h*3600+m*60);
}