#include <stdio.h>

int main(){
	int x,y;
	x=5;
	y=7;
	printf("가로가 %d이고 세로가 %d인 사각형 넓이는 %d입니다.\n",x,y,x*y);
}