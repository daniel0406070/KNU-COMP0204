#include <stdio.h>

int main(){
	int f=59,m=47,s=35,b=29;
    int sum=f+m+s+b;
    printf("우리 가족이 현재까지 살아온 일 수는 %d일입니다.\n",sum*365);
}