#include <stdio.h>

int main(){
	int x;
    printf("이번 학기에 수강하는 총 학점은? ");
    scanf("%d",&x);
    printf("총 %d 학점을 듣는군요.\n",x);
}