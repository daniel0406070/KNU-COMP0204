#include <stdio.h>

int main(){
	float y=150,cm;
    cm=y*91.44;
    printf("거리 %f야드는 미터로 %f센티미터입니다.\n",y,cm);
}