#include <stdio.h>

int main(){
    int n;
    printf("숫자를 입력하세요 : ");
    scanf("%d",&n);
    printf("%2dx%3d=%3d\n",n,1,n*1);
    printf("%2dx%3d=%3d\n",n,2,n*2);
    printf("%2dx%3d=%3d\n",n,3,n*3);
    printf("%2dx%3d=%3d\n",n,4,n*4);
    printf("%2dx%3d=%3d\n",n,5,n*5);
    printf("%2dx%3d=%3d\n",n,6,n*6);
    printf("%2dx%3d=%3d\n",n,7,n*7);
    printf("%2dx%3d=%3d\n",n,8,n*8);
    printf("%2dx%3d=%3d\n",n,9,n*9);


}